const mongoose = require('mongoose');
const Bank = require('../../database/models/mongodb/Bank.js'); // Adjust the path according to your project structure
module.exports = {
  config: {
    name: "bank",
    version: "1.2",
    description: "Deposit or withdraw money from the bank and earn interest",
    guide: {
      vi: "",
      en: "{pn}Bank:\nInterest - Balance\n - Withdraw \n- Deposit \n- Transfer \n- Richest"
    },
    category: "economy",
    countDown: 15,
    role: 0,
    author: "Loufi | SiAM | Samuel\n\nModified: Shikaki"
  },
  onStart: async function ({ args, message, event, api, usersData }) {
    const { getPrefix } = global.utils;
    const p = getPrefix(event.threadID);

    const userMoney = await usersData.get(event.senderID, "money");
    const user = event.senderID;
    const info = await api.getUserInfo(user);
    const username = info[user].name;

    // Ensure MongoDB connection
    if (mongoose.connection.readyState !== 1) {
      return message.reply("Database not connected.");
    }

    let bankData = await Bank.findOne({ userID: user });
    if (!bankData) {
      bankData = new Bank({ userID: user });
      await bankData.save();
    }

    const bankBalance = bankData.bank || 0;
    const command = args[0]?.toLowerCase();
    const amount = parseInt(args[1]);
    const recipientUID = args[2] ? parseInt(args[2]) : null;

    switch (command) {
      case "deposit":
        if (isNaN(amount) || amount <= 0) {
          return message.reply("Please enter a valid amount to deposit.");
        }

        if (bankBalance >= 1e104) {
          return message.reply("Cannot deposit money when your bank balance is already at $1e104.");
        }

        if (userMoney < amount) {
          return message.reply("You don't have the required amount to deposit.");
        }

        bankData.bank += amount;
        await usersData.set(event.senderID, { money: userMoney - amount });
        await bankData.save();

        return message.reply(`Successfully deposited $${amount} into your bank account.`);
      
      case "withdraw":
        if (isNaN(amount) || amount <= 0) {
          return message.reply("Please enter the correct amount to withdraw.");
        }

        if (userMoney >= 1e104) {
          return message.reply("Cannot withdraw money when your balance is already at 1e104.");
        }

        if (amount > bankData.bank) {
          return message.reply("Requested amount is greater than the available balance.");
        }

        bankData.bank -= amount;
        await usersData.set(event.senderID, { money: userMoney + amount });
        await bankData.save();

        return message.reply(`Successfully withdrew $${amount} from your bank account.`);
      
      case "balance":
        return message.reply(`Your bank balance is: $${formatNumberWithFullForm(bankData.bank)}`);
      
      case "interest":
        const interestRate = 0.001; // 0.1% daily interest rate
        const lastInterestClaimed = bankData.lastInterestClaimed || 0;
        const currentTime = Date.now();
        const timeDiffInSeconds = (currentTime - lastInterestClaimed) / 1000;

        if (timeDiffInSeconds < 86400) {
          const remainingTime = Math.ceil(86400 - timeDiffInSeconds);
          const remainingHours = Math.floor(remainingTime / 3600);
          const remainingMinutes = Math.floor((remainingTime % 3600) / 60);

          return message.reply(`You can claim interest again in ${remainingHours} hours and ${remainingMinutes} minutes.`);
        }

        const interestEarned = bankData.bank * (interestRate / 970) * timeDiffInSeconds;

        if (bankData.bank <= 0) {
          return message.reply("You don't have any money in your bank account to earn interest.");
        }

        bankData.lastInterestClaimed = currentTime;
        bankData.bank += interestEarned;
        await bankData.save();

        return message.reply(`You have earned interest of $${formatNumberWithFullForm(interestEarned)}.`);
      
      case "transfer":
        if (isNaN(amount) || amount <= 0) {
          return message.reply("Please enter a valid amount to transfer.");
        }

        if (!recipientUID || !await Bank.findOne({ userID: recipientUID })) {
          return message.reply("Recipient not found in the bank database.");
        }

        if (recipientUID === user) {
          return message.reply("You cannot transfer money to yourself.");
        }

        const recipientBankData = await Bank.findOne({ userID: recipientUID });

        if (recipientBankData.bank >= 1e104) {
          return message.reply("The recipient's bank balance is already $1e104.");
        }

        if (amount > bankData.bank) {
          return message.reply("You don't have enough money to transfer.");
        }

        bankData.bank -= amount;
        recipientBankData.bank += amount;
        await bankData.save();
        await recipientBankData.save();

        return message.reply(`Successfully transferred $${amount} to the recipient with UID: ${recipientUID}`);
      
      case "richest":
        const topUsers = await Bank.find().sort({ bank: -1 }).limit(10).exec();
        const output = await Promise.all(topUsers.map(async (userData, index) => {
          const userName = await usersData.getName(userData.userID);
          const formattedBalance = formatNumberWithFullForm(userData.bank);
          return `[${index + 1}. ${userName} - $${formattedBalance}]`;
        }));

        return message.reply("Top 10 richest people:\n" + output.join('\n'));
      
      case "loan":
        const maxLoanAmount = 100000000;
        const userLoan = bankData.loan || 0;
        const loanPayed = bankData.loanPayed !== undefined ? bankData.loanPayed : true;

        if (isNaN(amount) || amount <= 0) {
          return message.reply("Please enter a valid loan amount.");
        }

        if (amount > maxLoanAmount) {
          return message.reply("The maximum loan amount is $100000000.");
        }

        if (!loanPayed && userLoan > 0) {
          return message.reply(`You cannot take a new loan until you pay off your current loan. Your current loan to pay: $${userLoan}`);
        }

        bankData.loan += amount;
        bankData.loanPayed = false;
        bankData.bank += amount;
        await bankData.save();

        return message.reply(`Successfully taken a loan of $${amount}.`);
      
      case "payloan":
        const loanBalance = bankData.loan || 0;

        if (isNaN(amount) || amount <= 0) {
          return message.reply("Please enter a valid amount to repay your loan.");
        }

        if (loanBalance <= 0) {
          return message.reply("You don't have any pending loan payments.");
        }

        if (amount > loanBalance) {
          return message.reply(`The amount to pay off the loan is greater than your due amount. Please pay the exact amount.`);
        }

        if (amount > userMoney) {
          return message.reply(`You do not have $${amount} to repay the loan.`);
        }

        bankData.loan -= amount;
        if (bankData.loan === 0) {
          bankData.loanPayed = true;
        }
        await usersData.set(event.senderID, { money: userMoney - amount });
        await bankData.save();

        return message.reply(`Successfully repaid $${amount} towards your loan. Your current loan to pay: $${bankData.loan}`);
      
      default:
        return message.reply("Please use one of the following valid commands: Deposit, Withdraw, Balance, Interest, Transfer, Richest, Loan, PayLoan.");
    }
  }
};

// Function to format a number with full forms (e.g., 1 Thousand, 133 Million, 76.2 Billion)
function formatNumberWithFullForm(number) {
  const fullForms = [
    "",
    "Thousand",
    "Million",
    "Billion",
    "Trillion",
    "Quadrillion",
    "Quintillion",
    "Sextillion",
    "Septillion",
    "Octillion",
    "Nonillion",
    "Decillion",
    "Undecillion",
    "Duodecillion",
    "Tredecillion",
    "Quattuordecillion",
    "Quindecillion",
    "Sexdecillion",
    "Septendecillion",
    "Octodecillion",
    "Novemdecillion",
    "Vigintillion",
    "Unvigintillion",
    "Duovigintillion",
    "Tresvigintillion",
    "Quattuorvigintillion",
    "Quinvigintillion",
    "Sesvigintillion",
    "Septemvigintillion",
    "Octovigintillion",
    "Novemvigintillion",
    "Trigintillion",
    "Untrigintillion",
    "Duotrigintillion",
    "Googol",
  ];

  // Calculate the full form of the number (e.g., Thousand, Million, Billion)
  let fullFormIndex = 0;
  while (number >= 1000 && fullFormIndex < fullForms.length - 1) {
    number /= 1000;
    fullFormIndex++;
  }

  // Format the number with two digits after the decimal point
  const formattedNumber = number.toFixed(2);

  // Add the full form to the formatted number
  return `${formattedNumber} ${fullForms[fullFormIndex]}`;
}
