module.exports = {
 config: {
 name: "listbox",
 version: "1.0",
 author: "Mesbah Bb'e",
 countDown: 15,
 role: 2,
 description: {
 vi: "",
 en: "Listing the threads where the bot participated."
 },
 category: "owner",
 guide: {
 en: " {pn}"
 }
 },
 
 onStart: async function({ api, event }) {
 const threadList = await api.getThreadList(100, null, ['INBOX']);
 const activeGroups = threadList.filter(group => group.isSubscribed && group.isGroup);
 
 const groupDetailsList = await Promise.all(activeGroups.map(async (groupInfo) => {
 const threadInfo = await api.getThreadInfo(groupInfo.threadID);
 return {
 id: groupInfo.threadID,
 name: groupInfo.name,
 memberCount: threadInfo.userInfo.length,
 };
 }));
 
 const validGroupDetails = groupDetailsList.filter(group => group !== null);
 validGroupDetails.sort((a, b) => b.memberCount - a.memberCount);
 
 let message = '';
 const groupIDs = [];
 
 validGroupDetails.forEach((group, index) => {
 message += `${index + 1}. ${group.name}\n» TID: ${group.id}\n» Member: ${group.memberCount}\n\n`;
 groupIDs.push(group.id);
 });
 
 api.sendMessage(
 message + 'Reply "out", "ban", or "join" followed by the order number to leave, ban, or join that thread!!',
 event.threadID,
 (err, data) => {
 global.GoatBot.onReply.set(data.messageID, {
 commandName: this.config.name,
 author: event.senderID,
 messageID: data.messageID,
 groupIDs,
 type: 'reply'
 });
 }
 );
 },
 
 onReply: async function({ api, event, args, threadsData, Reply }) {
 const { author, messageID, groupIDs } = Reply;
 if (author !== event.senderID) return;
 
 const [command, indexStr] = event.body.split(" ");
 const index = parseInt(indexStr) - 1;
 
 if (isNaN(index) || index < 0 || index >= groupIDs.length) {
 api.sendMessage("Invalid group number.", event.threadID);
 return;
 }
 
 const selectedGroupID = groupIDs[index];
 const userID = event.senderID;
 
 switch (command.toLowerCase()) {
 case "ban":
 const groupData = (await threadsData.get(selectedGroupID)).data || {};
 groupData.banned = 1;
 await threadsData.setData(selectedGroupID, { data: groupData });
 global.data.threadBanned.set(parseInt(selectedGroupID), 1);
 api.sendMessage(`[${selectedGroupID}] Ban successful!`, event.threadID, event.messageID);
 break;
 
 case "out":
 api.removeUserFromGroup(`${api.getCurrentUserID()}`, selectedGroupID);
 api.sendMessage(
 `Left the thread with ID: ${selectedGroupID}\n${(await threadsData.get(selectedGroupID)).threadName}`,
 event.threadID,
 event.messageID
 );
 break;
 
 case "join":
 const threadInfo = await api.getThreadInfo(selectedGroupID);
 const participantIDs = threadInfo.participantIDs;
 
 if (participantIDs.includes(userID)) {
 api.sendMessage(
 "You are already in this group. If you didn't find it, please check your message requests or spam box.",
 event.threadID
 );
 } else {
 api.addUserToGroup(userID, selectedGroupID, err => {
 api.sendMessage(
 err
 ? "I can't add you because your ID does not allow message requests or your account is private. Please add me then try again..."
 : "You have been added to this group. If you didn't find the message in your inbox, please check your message requests or spam box.",
 event.threadID
 );
 });
 }
 break;
 
 default:
 api.sendMessage("Invalid command.", event.threadID);
 break;
 }
 }
};