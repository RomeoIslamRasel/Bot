const axios = require('axios');

module.exports = {
 config: {
 name: "code",
 version: "1.5", // Updated version
 shortDescription: "Get code from Pastebin, Gist, RunMocky, Paste.c-net.org",
 longDescription: "Get code from Pastebin, Gist, RunMocky, Paste-C. Just send command with the link or reply to a message with the link.",
 author: "𝐀𝐒𝐈𝐅 𝐱𝟔𝟗 | Rômeo",
 role: 0,
 category: 'tools',
 countDown: 5,
 guide: {
 en: "{pn} [link]"
 }
 },

 onStart: async function ({ api, event, args }) {
 let codeUrl;

 if (event.type === "message_reply") {
 // Handling code from replied message
 codeUrl = event.messageReply.body.match(/https:\/\/pastebin\.com\/raw\/[a-zA-Z0-9]+|https:\/\/gist\.github\.com\/[^\/]+\/[^\/]+\/raw\/[a-zA-Z0-9]+|https:\/\/run\.mocky\.io\/[^\/]+|https:\/\/paste\.c-net\.org\/[a-zA-Z0-9]+|http:\/\/goatbin\.vercel\.app\/raw\/[a-zA-Z0-9]+/);
 if (codeUrl) {
 codeUrl = codeUrl[0];
 } else {
 return api.sendMessage('No valid link found in the replied message!', event.threadID, event.messageID);
 }
 } else {
 codeUrl = args[0];
 if (!codeUrl) {
 return api.sendMessage('Please provide a Pastebin, Gist, RunMocky, Paste.c-net.org, or GoatBin link!', event.threadID, event.messageID);
 }
 }

 const isPastebin = codeUrl.startsWith("https://pastebin.com/");
 const isGist = codeUrl.startsWith("https://gist.github.com/");
 const isRunMocky = codeUrl.startsWith("https://run.mocky.io/");
 const isPasteCNet = codeUrl.startsWith("https://paste.c-net.org/");
 const isGoatBin = codeUrl.startsWith("http://goatbin.vercel.app/");

 if (!isPastebin && !isGist && !isRunMocky && !isPasteCNet && !isGoatBin) {
 return api.sendMessage('Invalid link! Please provide a valid Pastebin, Gist, RunMocky, Paste.c-net.org, or GoatBin link.', event.threadID, event.messageID);
 }

 let rawUrl;
 if (isPastebin) {
 const codeId = codeUrl.split('/').pop();
 rawUrl = `https://pastebin.com/raw/${codeId}`;
 } else if (isGist) {
 const gistId = codeUrl.split('/').pop();
 const userId = codeUrl.split('/')[3];
 rawUrl = `https://gist.githubusercontent.com/${userId}/${gistId}/raw`;
 } else if (isRunMocky) {
 rawUrl = codeUrl; 
 } else if (isPasteCNet) {
 const pasteId = codeUrl.split('/').pop();
 rawUrl = `https://paste.c-net.org/${pasteId}`;
 } else if (isGoatBin) {
 const pasteId = codeUrl.split('/').pop();
 rawUrl = `http://goatbin.vercel.app/raw/${pasteId}`;
 }

 try {
 const response = await axios.get(rawUrl);
 const code = response.data;

 api.sendMessage(`${code}`, event.threadID, event.messageID);
 } catch (error) {
 console.error(error);
 api.sendMessage('An error occurred while fetching the code!', event.threadID, event.messageID);
 }
 }
};