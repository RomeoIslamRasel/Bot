const axios = require("axios");

module.exports = {
 config: {
 name: "cool",
 version: "1.0",
 author: "Fahim_Noob",
 countDown: 0,
 role: 0,
 longDescription: {
 en: "Text to Image"
 },
 category: "image",
 guide: {
 en: "{pn} prompt"
 }
 },
 onStart: async function ({ message, api, args, event }) {
 const prompt = args.join(" ");
 
 if (!prompt) {
 return message.reply("😡 Please provide a prompt");
 }
 
 api.setMessageReaction("⏳", event.messageID, () => {}, true);
 
 const startTime = new Date().getTime();
 
 message.reply("✅| Generating please wait.", async (err, info) => {
 try {
 const url = "https://smfahim.onrender.com/sdxl?prompt=" + encodeURIComponent(prompt);
 const imageStream = await global.utils.getStreamFromURL(url);
 
 const endTime = new Date().getTime();
 const timeTaken = (endTime - startTime) / 1000;
 
 const replyMessage = {
 body: `Here is your imagination 🥰\nTime taken: ${timeTaken} seconds`,
 attachment: imageStream
 };
 
 message.reply(replyMessage);
 
 let messageID = info.messageID;
 message.unsend(messageID);
 
 api.setMessageReaction("✅", event.messageID, () => {}, true);
 } catch (error) {
 console.error(error);
 message.reply("😔 Something went wrong, please try again later.");
 api.setMessageReaction("❌", event.messageID, () => {}, true);
 }
 });
 }
};