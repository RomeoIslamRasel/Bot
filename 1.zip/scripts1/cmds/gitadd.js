const axios = require('axios');
const path = require('path');

module.exports = {
 config: {
 name: "gitadd",
 version: "1.2",
 author: "Rômeo ", // Updated author name with emoji
 countDown: 5,
 role: 2,
 shortDescription: "Add, view, or delete files in a GitHub repo",
 longDescription: "Add a new file, view files in the scripts/cmds/ directory, or delete a file from a private GitHub repository.",
 category: "utility",
 guide: {
 en: "Use the command as follows:\n1. Add file: gitadd <file name>.js <code url | code>\n2. View file list: gitadd view\n3. Delete file: gitadd delete <file name>.js"
},
 },
 onStart: async function ({ api, message, args, event }) {
 const githubToken = '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'; // Add your GitHub token here securely
 const owner = 'update-1'; // Add your GitHub username 
 const repo = 'Update'; // Add your repo name
 const branch = 'main';

 // View files in the directory
 if (args[0] === 'view') {
 const directoryPath = 'scripts/cmds/'; // Directory to view
 try {
 const { data } = await axios.get(`https://api.github.com/repos/${owner}/${repo}/contents/${directoryPath}?ref=${branch}`, {
 headers: {
 Authorization: `token ${githubToken}`
 }
 });

 if (data.length === 0) {
 return message.reply(`No files found in ${directoryPath}.`);
 }

 const fileList = data.map(file => file.name).join('\n');
 return message.reply(`Files in ${directoryPath}:\n${fileList}`);
 } catch (error) {
 console.error(error);
 return message.reply("An error occurred while retrieving the file list. Please try again.");
 }
 }

 // Delete a file
 if (args[0] === 'delete') {
 if (args.length < 2) {
 return message.reply("Please provide the file name to delete.");
 }

 const fileName = args[1];
 const filePath = path.join('scripts', 'cmds', fileName);

 try {
 // Get file SHA to delete
 const { data } = await axios.get(`https://api.github.com/repos/${owner}/${repo}/contents/${filePath}?ref=${branch}`, {
 headers: {
 Authorization: `token ${githubToken}`
 }
 });

 const fileSha = data.sha;

 // Delete the file
 await axios.delete(`https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`, {
 headers: {
 Authorization: `token ${githubToken}`
 },
 data: {
 message: `Deleted ${fileName}`,
 sha: fileSha,
 branch: branch
 }
 });

 return message.reply(`File ${fileName} has been deleted.`);
 } catch (error) {
 console.error(error);
 return message.reply("An error occurred while deleting the file. Please try again.");
 }
 }

 // Add a new file if the command is not 'view' or 'delete'
 if (args.length < 2) {
 return message.reply("Please provide the file name and code content or code URL.");
 }

 const fileName = args[0];
 if (!fileName.endsWith('.js')) {
 return message.reply("The file name must end with '.js'.");
 }
 const codeSource = args.slice(1).join(" ");
 const filePath = path.join('scripts', 'cmds', fileName);

 try {
 let code;

 if (codeSource.startsWith('http://') || codeSource.startsWith('https://')) {
 const response = await axios.get(codeSource);
 code = response.data;
 } else {
 code = codeSource;
 }

 // Get the latest commit SHA for the branch
 const { data: refData } = await axios.get(`https://api.github.com/repos/${owner}/${repo}/git/ref/heads/${branch}`, {
 headers: {
 Authorization: `token ${githubToken}`
 }
 });
 const latestCommitSha = refData.object.sha;

 // Get the latest commit data
 const { data: commitData } = await axios.get(`https://api.github.com/repos/${owner}/${repo}/git/commits/${latestCommitSha}`, {
 headers: {
 Authorization: `token ${githubToken}`
 }
 });
 const baseTreeSha = commitData.tree.sha;

 // Create a new blob (file) for the code
 const { data: blobData } = await axios.post(`https://api.github.com/repos/${owner}/${repo}/git/blobs`, {
 content: code,
 encoding: 'utf-8'
 }, {
 headers: {
 Authorization: `token ${githubToken}`
 }
 });

 // Create a new tree with the added file
 const { data: treeData } = await axios.post(`https://api.github.com/repos/${owner}/${repo}/git/trees`, {
 base_tree: baseTreeSha,
 tree: [
 {
 path: filePath,
 mode: '100644',
 type: 'blob',
 sha: blobData.sha
 }
 ]
 }, {
 headers: {
 Authorization: `token ${githubToken}`
 }
 });

 // Create a new commit with the new tree
 const { data: newCommitData } = await axios.post(`https://api.github.com/repos/${owner}/${repo}/git/commits`, {
 message: `Added ${fileName}`,
 tree: treeData.sha,
 parents: [latestCommitSha]
 }, {
 headers: {
 Authorization: `token ${githubToken}`
 }
 });

 // Update the reference for the branch to point to the new commit
 await axios.patch(`https://api.github.com/repos/${owner}/${repo}/git/refs/heads/${branch}`, {
 sha: newCommitData.sha
 }, {
 headers: {
 Authorization: `token ${githubToken}`
 }
 });

 message.reply(` ${fileName} added`);
 } catch (error) {
 console.error(error);
 message.reply("An error occurred while adding the file. Please try again.");
 }
 }
};
