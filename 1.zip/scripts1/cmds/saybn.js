const axios = require('axios');
const { createReadStream, unlinkSync, writeFileSync } = require('fs-extra');
const path = require('path');

module.exports = {
 config: {
 name: "saybn",
 aliases: ['x'],
 version: "1.0",
 author: "Rômeo",
 countDown: 5,
 role: 0,
 shortDescription: "Convert text to speech and send as audio",
 longDescription: "",
 category: "fun",
 guide: {
 vi: "{pn} text",
 en: "{pn} text"
 }
 },
 onStart: async function ({ api, event, args }) {
 try {
 
 const content = event.type === "message_reply" ? event.messageReply.body : args.join(" ");
 const languageToSay = ["bn"].some(item => content.startsWith(item)) ? content.split(" ")[0] : 'bn';
 const msg = languageToSay !== 'bn' ? content.slice(languageToSay.length).trim() : content;

 
 const filePath = path.resolve(__dirname, 'cache', `${event.threadID}_${event.senderID}.mp3`);

 
 const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(msg)}&tl=${languageToSay}&client=tw-ob`;
 const response = await axios({ url, responseType: 'arraybuffer' });
 writeFileSync(filePath, response.data);

 
 api.sendMessage({
 attachment: createReadStream(filePath)
 }, event.threadID, () => unlinkSync(filePath));
 } catch (e) {
 console.error("Error occurred in 'say' command:", e);
 api.sendMessage("An error occurred while processing your request.", event.threadID);
 }
 }
};