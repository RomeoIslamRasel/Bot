const axios = require('axios');
const fs = require('fs').promises;
const path = require('path');

module.exports = {
 config: {
 name: "hastebin",
 aliases: ["haste"],
 version: "1.0",
 author: "Rômeo", // if you change Credit, You're a gay
 countDown: 5,
 role: 2,
 shortDescription: {
 en: "Upload files or code snippets to Hastebin and sends link"
 },
 longDescription: {
 en: "This command allows you to upload files or code snippets to Hastebin and sends the link to the file."
 },
 category: "tools",
 guide: {
 en: "To use this command, type !hastebin <filename> to upload a file or reply to a message with the code you want to upload."
 }
 },

 onStart: async function({ api, event, args }) {
 const hastebinUrl = 'https://hastebin.skyra.pw/documents';

 if (event.type === "message_reply") {
 // Handling code from replied message
 const code = event.messageReply.body;
 try {
 console.log("Uploading code to Hastebin:", code);
 const response = await axios.post(hastebinUrl, code, {
 headers: {
 'Content-Type': 'text/plain'
 }
 });
 console.log("Response from Hastebin:", response.data);
 const pasteKey = response.data.key;
 const hasteUrl = `https://hastebin.skyra.pw/${pasteKey}`;
 api.sendMessage(`Code uploaded to Hastebin: ${hasteUrl}`, event.threadID);
 } catch (error) {
 console.error("Error uploading to Hastebin:", error.response ? error.response.data : error.message);
 api.sendMessage('An error occurred while uploading the code!', event.threadID);
 }
 } else {
 
 const fileName = args[0];
 if (!fileName) {
 return api.sendMessage('Please provide a filename!', event.threadID);
 }

 const filePathWithoutExtension = path.join(__dirname, '..', 'cmds', fileName);
 const filePathWithExtension = path.join(__dirname, '..', 'cmds', fileName + '.js');

 let filePath;

 try {
 
 await fs.access(filePathWithoutExtension).catch(() => fs.access(filePathWithExtension));
 filePath = (await fs.access(filePathWithoutExtension).then(() => filePathWithoutExtension).catch(() => filePathWithExtension));
 } catch {
 return api.sendMessage('File not found!', event.threadID);
 }

 try {
 const data = await fs.readFile(filePath, 'utf8');
 console.log("Uploading file to Hastebin:", data);
 const response = await axios.post(hastebinUrl, data, {
 headers: {
 'Content-Type': 'text/plain'
 }
 });
 console.log("Response from Hastebin:", response.data);
 const pasteKey = response.data.key;
 const hasteUrl = `https://hastebin.skyra.pw/${pasteKey}`;
 api.sendMessage(`File uploaded to Hastebin: ${hasteUrl}`, event.threadID);
 } catch (error) {
 console.error("Error uploading to Hastebin:", error.response ? error.response.data : error.message);
 api.sendMessage('An error occurred while uploading the file!', event.threadID);
 }
 }
 },
};