const { CustomError } = global.utils;

module.exports = {
    config: {
        name: "vip",
        version: "1.1",
        author: "Sadman",
        countDown: 5,
        role: 2,
        shortDescription: "Manage VIP members",
        longDescription: "Add, list, and remove VIP members of the bot.",
        category: "OWNER",
        guide: {
            en: "{pn} add [@mention | uid | reply]\n{pn} list\n{pn} remove [@mention | uid | reply]"
        }
    },

    langs: {
        en: {
            added: "✅ | Added %1 as a VIP member.",
            alreadyVIP: "⚠️ | %1 is already a VIP member.",
            notVIP: "⚠️ | %1 is not a VIP member.",
            removed: "✅ | Removed %1 from VIP members.",
            listEmpty: "There are no VIP members yet.",
            list: "👑 | VIP Members:\n%1",
            userNotFound: "User not found.",
            error: "An error occurred: %1"
        }
    },

    onStart: async function ({ message, event, args, globalData, usersData, getLang }) {
        const { mentions, messageReply } = event;
        const targetIDs = [];

        try {
            if (args[0] === "add" || args[0] === "remove" || args[0] === "del" || args[0] === "delete" || args[0] === "rm") {
                if (Object.keys(mentions).length > 0) {
                    targetIDs.push(...Object.keys(mentions));
                } else if (messageReply) {
                    targetIDs.push(messageReply.senderID);
                } else if (!isNaN(args[1])) {
                    targetIDs.push(args[1]);
                } else {
                    return message.reply(getLang("userNotFound"));
                }
            }

            let vipMembers = await globalData.get("vipMembers", "data", []);
            let name;
            switch (args[0]) {
                case "add": {
                    
                    const added = [], alreadyVIP = [];
                    for (const targetID of targetIDs) {
                         name = await usersData.getName(targetID);
                        if (!vipMembers.includes(targetID)) {
                            vipMembers.push(targetID);
                            added.push(`${name} (${targetID})`); 
                        } else {
                            alreadyVIP.push(`${name} (${targetID})`); 
                        }
                    }
                    await globalData.set("vipMembers", vipMembers, "data");
                    return message.reply(
                        (added.length > 0 ? getLang("added", name,'(', added.join(", "),')',) : "") +
                        (alreadyVIP.length > 0 ? "\n" + getLang("alreadyVIP", alreadyVIP.join(", ")) : "")
                    );
                }
                case "list": {
                    if (vipMembers.length === 0) {
                        return message.reply(getLang("listEmpty"));
                    }

                    const vipList = (await Promise.all(vipMembers.map(async uid => {
                        try {
                            const name = await usersData.getName(uid);
                            return `- ${name} (${uid})`;
                        } catch (e) {
                            return `- ${uid} (User not found)`;
                        }
                    }))).join("\n");

                    return message.reply(getLang("list", vipList));
                }
                case "remove":
                case "rm":
                case "delete":
                case "del": {
                    const removed = [], notVIP = [];
                    for (const targetID of targetIDs) {
                        const name = await usersData.getName(targetID); 
                        if (vipMembers.includes(targetID)) {
                            vipMembers.splice(vipMembers.indexOf(targetID), 1);
                            removed.push(`${name} (${targetID})`); 
                        } else {
                            notVIP.push(`${name} (${targetID})`); 
                        }
                    }
                    await globalData.set("vipMembers", vipMembers, "data");
                    return message.reply(
                        (removed.length > 0 ? getLang("removed", removed.join(", ")) : "") +
                        (notVIP.length > 0 ? "\n" + getLang("notVIP", notVIP.join(", ")) : "")
                    );
                }
                default: {
                    return message.SyntaxError();
                }
            }
        } catch (error) {
            if (error instanceof CustomError && error.name === "KEY_NOT_FOUND") {
                console.error("vipMembers key not found. Creating...");
                await globalData.create("vipMembers", { data: [] });
                message.reply("The VIP list was just initialized. Please try your command again.");
            } else {
                console.error("Error in vip command:", error);
                message.reply(getLang("error", error.message));
            }
        }
    }
};
