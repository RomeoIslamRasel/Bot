const axios = require('axios');
const fs = require('fs');

module.exports = {
 config: {
 name: "magen",
 version: "1.2",
 author: "ArYAN",
 countDown: 10,
 role: 0,
 shortDescription: {
 en: 'Generate images..'
 },
 longDescription: {
 en: "Generate images using Magic Studio API."
 },
 category: "media",
 guide: {
 en: "{p}magen <prompt>"
 }
 },

 onStart: async function({ message, args, api, event }) {
 try {
 const prompt = args.join(" ");
 if (!prompt) {
 return message.reply("❌| Invalid Prompts.");
 }

 api.setMessageReaction("⏰", event.messageID, () => {}, true);

 const startTime = new Date().getTime();
 
 const baseURL = `https://xapiz.onrender.com/api/mageai`;
 const params = {
 prompt: prompt,
 };

 const response = await axios.get(baseURL, {
 params: params,
 responseType: 'stream'
 });

 const endTime = new Date().getTime();
 const timeTaken = (endTime - startTime) / 1000;

 api.setMessageReaction("✅", event.messageID, () => {}, true);

 const fileName = 'magen.png';
 const filePath = `/tmp/${fileName}`; 

 const writerStream = fs.createWriteStream(filePath);
 response.data.pipe(writerStream);

 writerStream.on('finish', function() {
 message.reply({
 body: `✅| Here is your generated in ${timeTaken} seconds`,
 attachment: fs.createReadStream(filePath)
 });
 });

 } catch (error) {
 console.error('Error generating image:', error);
 message.reply("❌ Failed .");
 }
 }
};