const axios = require('axios');

module.exports = {
  config: {
    name: "give",
    version: "1.0",
    author: "itz Aryan",
    countDown: 2,
    role: 2, 
    longDescription: {
      en: "Updates the specified user's money by a given amount."
    },
    category: "owner",
    guide: {
      en: "{pn} <userID> <amount>"
    },
  },
  onStart: async function ({ message, event, usersData, commandName, getLang, args, api }) {
    try {
      const userID = args[0];
      const amount = parseInt(args[1], 10);

      if (!userID || isNaN(amount)) {
        return api.sendMessage("Please provide a valid userID and amount.", event.threadID, event.messageID);
      }

      const userData = await usersData.get(userID);

      if (!userData) {
        return api.sendMessage("User data not found.", event.threadID, event.messageID);
      }

      userData.money = (userData.money || 0) + amount;
      await usersData.set(userID, userData);

      api.sendMessage(`User's money updated successfully. New balance: ${userData.money}`, event.threadID, event.messageID);
    } catch (error) {
      console.error("Error updating user's money:", error);
      api.sendMessage("An error occurred while updating the user's money.", event.threadID, event.messageID);
    }
  }
};