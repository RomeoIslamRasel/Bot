const fetch = require("node-fetch");
const { getPrefix, getStreamFromURL } = global.utils;

module.exports = {
 config: {
 name: "deviceinfo",
 aliases: ["device"],
 version: "1.0",
 author: "Team Calyx",
 countDown: 15,
 role: 0,
 shortDescription: {
 en: "Get information about a device.",
 },
 longDescription: {
 en: "Retrieve detailed information about the specified device.",
 },
 category: "info",
 guide: {
 en: "{pn}deviceinfo (device name)",
 },
 },
 onStart: async function ({ api, args, event }) {
 const search = args.join(" ");

 if (!search) {
 api.sendMessage("Please provide the name of the device you want to search for.", event.threadID);
 return;
 }

 const searchUrl = `https://device-pi.vercel.app/api?query=${encodeURIComponent(search)}`; // Adjust URL if hosted elsewhere

 try {
 const searchResponse = await fetch(searchUrl);
 const searchResults = await searchResponse.json();

 if (searchResults.results.length === 0) {
 api.sendMessage(`❌ No results found for '${search}'. Please try again with a different device name.`, event.threadID);
 return;
 }

 let replyMessage = "🔍 Search Results:\n\n";
 for (let i = 0; i < searchResults.results.length; i++) {
 const device = searchResults.results[i];
 replyMessage += `${i + 1}. ${device.name}\n`;
 }
 replyMessage += "\nReply with the number of the device you want to get info about.";

 const reply = await api.sendMessage(replyMessage, event.threadID);
 const replyMessageID = reply.messageID;

 global.GoatBot.onReply.set(replyMessageID, {
 commandName: "deviceinfo",
 author: event.senderID,
 messageID: replyMessageID,
 results: searchResults.results,
 });
 } catch (error) {
 console.error(error);
 api.sendMessage("An error occurred while fetching device information.", event.threadID);
 }
 },
 onReply: async function ({ api, event, Reply }) {
 const { author, results } = Reply;

 if (event.senderID !== author) return;

 const selectedNumber = parseInt(event.body);

 if (isNaN(selectedNumber) || selectedNumber <= 0 || selectedNumber > results.length) {
 api.sendMessage("Invalid option selected. Please reply with a valid number.", event.threadID);
 return;
 }

 const selectedDevice = results[selectedNumber - 1];
 const url = selectedDevice.url;
 const infoUrl = `https://device-pi.vercel.app/info?url=${encodeURIComponent(url)}`; // Adjust URL if hosted elsewhere

 try {
 const infoResponse = await fetch(infoUrl);
 const deviceInfo = await infoResponse.json();

 if (infoResponse.ok) {
 let infoMessage = `📱 Device: ${deviceInfo.title}\n`;
 infoMessage += `📅 Release Date: ${deviceInfo.releaseDate}\n`;
 infoMessage += `📏 Dimensions: ${deviceInfo.dimensions}\n`;
 infoMessage += `💾 Storage: ${deviceInfo.storage}\n`;
 infoMessage += `🔍 Display Info: ${deviceInfo.displayInfo}\n`;
 infoMessage += `📏 Display Inch: ${deviceInfo.displayInch}\n`;
 infoMessage += `📷 Camera Pixel: ${deviceInfo.cameraPixel}\n`;
 infoMessage += `🎥 Video Pixel: ${deviceInfo.videoPixel}\n`;
 infoMessage += `🔒 RAM Size: ${deviceInfo.ramSize}\n`;
 infoMessage += `🧰 Chipset Info: ${deviceInfo.chipsetInfo}\n`;
 infoMessage += `🔋 Battery Type: ${deviceInfo.batteryType}\n`;
 infoMessage += `🔋 Battery Capacity: ${deviceInfo.batteryCapacity}\n`;
 

 const image = await getStreamFromURL(deviceInfo.imageUrl);

 const msgSend = await api.sendMessage(
 {
 body: infoMessage,
 attachment: image,
 },
 event.threadID
 );
 } else {
 api.sendMessage("Sorry, the device information could not be retrieved.", event.threadID);
 }
 } catch (error) {
 console.error(error);
 api.sendMessage("An error occurred while fetching device information.", event.threadID);
 }
 },
};