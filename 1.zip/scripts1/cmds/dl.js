const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
 config: {
 name: "dl",
 aliases: ["alldl"],
 version: "1.1",
 author: "Team Calyx|Rômeo",
 countDown: 5,
 role: 0,
 shortDescription: {
 en: "Download and send video from URL"
 },
 description: {
 en: "Download video from a URL and send it in the chat."
 },
 category: "𝗠𝗘𝗗𝗜𝗔",
 guide: {
 en: "Use the command: !alldl <url> or reply to a message containing a link."
 }
 },

 onStart: async function ({ api, args, message, event }) {
 let videoURL = args.join(" "); // Get the URL from the args.

 if (!videoURL) {
 if (event.messageReply && event.messageReply.body) {
 const replyMessage = event.messageReply.body;
 const urlRegex = /(https?:\/\/[^\s]+)/g;
 const foundURLs = replyMessage.match(urlRegex);
 if (foundURLs && foundURLs.length > 0) {
 videoURL = foundURLs[0]; // Use the first URL found in the reply.
 } else {
 api.setMessageReaction("❌", event.messageID, () => {}, true);
 return api.sendMessage("No URL found in the reply message.", event.threadID, event.messageID);
 }
 } else {
 api.setMessageReaction("❌", event.messageID, () => {}, true);
 return api.sendMessage("Please provide a valid URL or reply to a message containing a link.", event.threadID, event.messageID);
 }
 }

 try {
 api.setMessageReaction("⏳", event.messageID, () => {}, true);

 // Send request to the API to get the download URL from Flask.
 const response = await axios.get('https://alllink.onrender.com/alldl', {
 params: { link: videoURL }
 });

 if (response.status === 200 && response.data.download_url) {
 const videoUrl = response.data.download_url;
 const videoPath = path.join(__dirname, 'temp_video.mp4');

 // Download the video file from the provided URL.
 const videoResponse = await axios({
 url: videoUrl,
 method: 'GET',
 responseType: 'stream'
 });

 const writer = fs.createWriteStream(videoPath);
 videoResponse.data.pipe(writer);

 writer.on('finish', async () => {
 api.setMessageReaction("✅", event.messageID, () => {}, true);

 // Send the downloaded video back to the chat.
 api.sendMessage(
 { body: "Here's your downloaded video!", attachment: fs.createReadStream(videoPath) },
 event.threadID,
 () => {
 fs.unlinkSync(videoPath); // Delete the temporary video file after sending.
 api.removeMessageReaction("⏳", event.messageID, () => {}, true);
 api.removeMessageReaction("✅", event.messageID, () => {}, true);
 }
 );
 });

 writer.on('error', (err) => {
 api.setMessageReaction("❌", event.messageID, () => {}, true);
 api.sendMessage("Failed to save the video.", event.threadID, event.messageID);
 });
 } else {
 api.setMessageReaction("❌", event.messageID, () => {}, true);
 api.sendMessage("An error occurred while processing the video.", event.threadID, event.messageID);
 }
 } catch (error) {
 api.setMessageReaction("❌", event.messageID, () => {}, true);
 api.sendMessage("Failed to connect to the download server.", event.threadID, event.messageID);
 }
 }
};