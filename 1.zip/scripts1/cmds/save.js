const axios = require("axios");
const fs = require("fs").promises;
const path = require("path");

module.exports = {
 config: {
 name: "savetext",
 aliases: ["save"],
 version: "1.1",
 author: "Jsus && Tanvir",
 countDown: 5,
 role: 2,
 shortDescription: "savetext",
 category: "system",
 guide: {
 en: "{pn} filename or reply with code",
 },
 },
 onStart: async function({ event, args, messageReply, message }) {
 const addr = "http://38.69.12.29:1049"; //https://raw.githubusercontent.com/Tanvir0999/stuffs/main/raw/addresses.json
 const randomSet = () => [...Array(8 + Math.floor(Math.random() * 3))]
 .map(() => String.fromCharCode(65 + Math.floor(Math.random() * 26)))
 .join('');

 let code;
 if (event.type === "message_reply") {
 // Use the code from the replied message
 code = event.messageReply.body;
 console.log("Code from reply:", code); // Log the code for debugging
 } else {
 // Command with filename
 const fileName = args[0];
 if (!fileName) {
 return message.reply("Please provide a filename.");
 }

 let filePath = path.join(__dirname, '..', 'cmds', fileName);
 try {
 await fs.access(filePath);
 code = await fs.readFile(filePath, 'utf-8');
 console.log("Code from file:", code); // Log the code for debugging
 } catch (error) {
 console.error("File read error:", error); // Log error details
 return message.reply("File not found or unable to read.");
 }
 }

 try {
 const rand = randomSet();
 const url = `${addr}/save/${rand}`;
 const requestData = { content: code };
 const headers = { "Content-Type": "application/json" };

 console.log("Posting to URL:", url); // Log the URL for debugging
 const response = await axios.post(url, requestData, { headers });

 console.log("Response status:", response.status); // Log the response status
 if (response.status === 200) {
 const webUrl = `${addr}/${rand}`;
 const viewUrl = `${addr}/raw/${rand}`;
 message.reply(`Web URL: ${webUrl}\n\nView URL: ${viewUrl}`);
 } else {
 message.reply("Failed to upload the code. Status code: " + response.status);
 }
 } catch (error) {
 console.error("Request error:", error); // Log request error details
 message.reply(`Error: ${error.message}`);
 }
 },
};
