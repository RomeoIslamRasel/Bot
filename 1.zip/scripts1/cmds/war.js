module.exports = {
	config: {
		name: "war",
		version: "1.0",
		author: "Rômeo",
		role: 2,
		category: "tools",
		guide: {
			vi: "Not Available",
			en: "cpx @(mention) | cpx stop"
		}
	},

	onStart: async function ({ api, event, userData, args }) {
		if (args[0] === "stop") {
			this.stopWar = true;
			return api.sendMessage("War sequence stopped.", event.threadID);
		}

		var mention = Object.keys(event.mentions)[0];
		if (!mention) return api.sendMessage("আপনি কাকে চু'দতে চান", event.threadID);

		let name = event.mentions[mention];
		var arraytag = [];
		arraytag.push({ id: mention, tag: name });
		var a = function (a) { api.sendMessage(a, event.threadID); }

		this.stopWar = false; // Initialize stop flag

		const messages = [
			"চুদা লো🤞🏻👅👅",
			{ body: "খাংকির পোলা তর মারে চুদি (+)🙊💋 " + " " + name, mentions: arraytag },
			{ body: "খাংকির পোলা তর কচি বোন রে চুদি 💋🤣 " + " " + name, mentions: arraytag },
			{ body: " মাদারচোদ তর আম্মু পম পম খাংকির পো😜💔 " + " " + name, mentions: arraytag },
			{ body: " খাংকির পোলা তর কচি ভুদায় ভুদায় কামর দিমু...🔥 " + " " + name, mentions: arraytag },
			{ body: " খাংকি মাগির পোলা কথা ক কম কম তর আম্মু রে চুদে বানামু আইটেম বোম 😈😍" + " " + name, mentions: arraytag },
			{ body: "  depression থেকেও তর মাইরে চু*** দি😈👿" + " " + name, mentions: arraytag },
			{ body: "  তর আম্মু রে আচার এর লোভ দেখি চুদি মাগির পোলা🤬" + " " + name, mentions: arraytag },
			{ body: " বান্দির পোলা তর কচি বোনের ভুদা ফাক কর থুতু দিয়ে ভুদায় ধোন ডুকামু 🤟💋❤" + " " + name, mentions: arraytag },
			{ body: "বান্দি মাগির পোলা তর আম্মু রে চুদি তর দুলা ভাই এর কান্দে ফেলে  🤝😂💋🤣" + " " + name, mentions: arraytag },
			{ body: " উফফফ খাদ্দামা মাগির পোলা তর আম্মুর কালা ভুদায় আমার মাল আউট তর কচি বোন রে উপ্তা করে এবার চুদবো  💉😋💋" + " " + name, mentions: arraytag },
			{ body: " অনলাইনে গালি বাজ হয়ে গেছত মাগির পোলা এমন চুদা দিমু লাইফ টাইম মনে রাখবি রোমিও তর বাপ মাগির ছেলে 😘💋❤" + " " + name, mentions: arraytag },
			{ body: "ভাতিজা শোন তর আম্মু রে চুদলে রাগ করবি না তো আচ্ছা যা রাগ করিস না তর আম্মুর কালা ভুদায় আর চুদলাম না তো বোন এর জামা টা খুলে দে  💋❤" + " " + name, mentions: arraytag },
			{ body: "হাই মাদারচোদ তর তর বেশ্যা জাতের আম্মু টা রে আদর করে করে চুদি 🙊💋😈" + " " + name, mentions: arraytag },
			{ body: " ~ চুদা কি আরো খাবি মাগির পোল 🍷😂🤣" + " " + name, mentions: arraytag },
			{ body: " খানকির পোলা 🥰💋❤" + " " + name, mentions: arraytag },
			{ body: " মাদারচোদ🤣😂💋" + " " + name, mentions: arraytag },
			{ body: "  ব্যাস্যার পোলা😂😅" + " " + name, mentions: arraytag },
			{ body: " ব্যাশ্যা মাগির পোলা🤣🥳🥳😂" + " " + name, mentions: arraytag },
			{ body: "  পতিতা মাগির পোলা 😂😂" + " " + name, mentions: arraytag },
			{ body: " Welcome শুয়োরের বাচ্চা 🥰" + " " + name, mentions: arraytag },
			{ body: "কুত্তার বাচ্ছা তোর বোনের ভোদায় মাগুর মাছ চাষ করুম😂😂" + " " + name, mentions: arraytag },
			{ body: " খাঙ্কিরপোলা পোলা তর বোনের  হোগায় ইনপুট, তর মায়ের ভোদায় আউটপুট (+) বস্তির ছেলে তর মায়ের ভুদাতে পোকা💋😂" + " " + name, mentions: arraytag },
			{ body: "কান্দে ফালাইয়া তর মায়েরে চুদি💋💋" + " " + name, mentions: arraytag },
			{ body: " তর আম্মুর উপ্তা কইরা চুদা দিমু।😈❤" + " " + name, mentions: arraytag },
			{ body: " তর বোন ভোদা ছিল্লা লবণ লাগায় দিমু।😈💋" + " " + name, mentions: arraytag },
			"~ রোমিও এর পুত। যা ভাগ🤖😈💋"
		];

		for (let i = 0; i < messages.length; i++) {
			if (this.stopWar) break; // Check if stop flag is set
			setTimeout(() => { a(messages[i]) }, i * 1000);
		}
	}
};
