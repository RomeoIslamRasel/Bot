module.exports.config = {
 name: "approvelist",
 aliases: ["apvlist", "apv"],
 version: "1.6",
 author: "Dipto",
 role: 1, // Admin role
 category: "box chat",
 description: {
 en: "Accept approve IDs"
 },
 countDown: 2,
 guide: {
 en: "{pn} to see pending requests. Reply with the number or 'all' to approve all."
 }
};

module.exports.onStart = async ({ api, event }) => {
 try {
 const info = await api.getThreadInfo(event.threadID);
 const app = info.approvalQueue;

 // Check if the approval mode is enabled
 if (!info.approvalMode) {
 return api.sendMessage("🤣😂 idiot first on approval", event.threadID, event.messageID);
 }

 // Collect inviter and requester details
 const inid = app.map(bal => bal.inviterID);
 const reqid = app.map(bal => bal.requesterID);

 const outarray = await Promise.all(inid.map(async (member, index) => {
 const inviterInfo = await api.getUserInfo(member);
 const requesterInfo = await api.getUserInfo(reqid[index]);

 return {
 inviterID: member,
 inviterName: inviterInfo[member].name,
 requesterID: reqid[index],
 requesterName: requesterInfo[reqid[index]].name
 };
 }));

 let groups = `╭─✦ Approve List ✦─╮\n`;
 outarray.forEach((entry, index) => {
 groups += `├‣ ${index + 1}. Inviter: ${entry.inviterName}\n├‣ ID: ${entry.inviterID}\n`;
 groups += `├‣ Requester: ${entry.requesterName}\n├‣ ID: ${entry.requesterID}\n`;
 });
 groups += `╰───────────────────⧕\nReply to this message with the number of the ID you want to accept, or reply with 'all' to approve all.`;

 api.sendMessage(groups, event.threadID, (error, info) => {
 if (error) return api.sendMessage(`Error: ${error.message}`, event.threadID, event.messageID);
 global.GoatBot.onReply.set(info.messageID, {
 commandName: this.config.name,
 messageID: info.messageID,
 author: event.senderID,
 outarray
 });
 }, event.messageID);

 } catch (error) {
 api.sendMessage(`Error: ${error.message}`, event.threadID, event.messageID);
 }
};

module.exports.onReply = async ({ api, event, Reply, usersData }) => {
 try {
 const { author, messageID, outarray } = Reply;
 if (event.senderID != author) return;

 const choice = event.body.toLowerCase();

 // Check if user wants to approve all
 if (choice === 'all' || choice === 'approve all') {
 // Approve all members in the approval queue
 const promises = outarray.map(entry => api.addUserToGroup(entry.requesterID, event.threadID));
 await Promise.all(promises);
 api.sendMessage(`✅ | Approved all ${outarray.length} users successfully.`, event.threadID, event.messageID);
 } else {
 // Approve a specific member based on their number in the list
 const index = parseInt(choice);
 if (isNaN(index) || index < 1 || index > outarray.length) {
 return api.sendMessage("Invalid choice. Please try again.", event.threadID, event.messageID);
 }

 const selectedID = outarray[index - 1].requesterID;
 await api.addUserToGroup(selectedID, event.threadID);
 const senderName = await usersData.getName(event.senderID);
 api.sendMessage(`✅ | User ${selectedID} approved successfully by ${senderName}`, event.threadID, event.messageID);
 }

 global.GoatBot.onReply.delete(messageID);
 } catch (error) {
 api.sendMessage(`Sorry, ${error.message}`, event.threadID, event.messageID);
 }
};