const axios = require('axios');
const fs = require('fs-extra');
const path = require('path');
const yts = require("yt-search");

async function downloadFile(url, filePath) {
 const writer = fs.createWriteStream(filePath);
 const response = await axios({
 url,
 method: 'GET',
 responseType: 'stream'
 });
 response.data.pipe(writer);
 return new Promise((resolve, reject) => {
 writer.on('finish', resolve);
 writer.on('error', reject);
 });
}

module.exports = {
 config: {
 name: "ytb2", 
 version: "1.0", 
 author: "Nova", 
 countDown: 5,
 role: 0,
 shortDescription: {
 en: "Download video or audio from YouTube."
 },
 longDescription: {
 en: "Download video or audio from YouTube using an external API."
 },
 category: "𝗠𝗘𝗗𝗜𝗔",
 guide: {
 en: "{pn} [v | a] <search query>" 
 }
 },

 onStart: async function ({ message, event, args, commandName }) {
 const type = args[0]?.toLowerCase();
 const query = args.slice(1).join(" ");

 if (!["v", "-v", "-a", "a"].includes(type) || !query) {
 return message.reply("❌ | Invalid usage! Please use:\n {pn} [v | a] <search query>"); 
 }

 try {
 const searchResults = await yts(query);

 if (!searchResults.videos.length) {
 return message.reply("❌ | No videos found for the given query."); 
 }

 const top5Videos = searchResults.videos.slice(0, 5); 
 
 const choiceList = top5Videos.map((video, index) => 
 `${index + 1}. ${video.title} (${video.timestamp})`
 ).join("\n");

 message.reply(`Here are the top 5 search results:\n${choiceList}\n\nReply with the number of your choice.`,
 (err, info) => {
 global.GoatBot.onReply.set(info.messageID, {
 commandName,
 messageID: info.messageID,
 author: event.senderID,
 type,
 videos: top5Videos
 });
 }
 );

 } catch (error) {
 console.error("Error:", error.message);
 return message.reply(`❌ | An error occurred while processing your request.\n${error.message}`); 
 }
 },
 
 onReply: async function ({ message, event, api, Reply, args }) {
 const { author, type, videos, messageID: choiceListMessageId } = Reply; 
 const choice = parseInt(args[0]);

 if (event.senderID !== author || isNaN(choice) || choice < 1 || choice > 5) {
 return message.reply("❌ | Invalid choice!"); 
 }

 api.unsendMessage(choiceListMessageId); 
 try {
 const selectedVideo = videos[choice - 1];
 const videoURL = selectedVideo.url; 
 const videoTitle = selectedVideo.title; 

 if (type === "v" || type === "-v") {
 const downloadApiUrl = `https://auandvi.onrender.com/download?url=${videoURL}&type=mp4`;
 const downloadApiResponse = await axios.get(downloadApiUrl);
 const videoDownloadUrl = `https://auandvi.onrender.com/${encodeURIComponent(downloadApiResponse.data.download_url)}`;

 const filePath = `${__dirname}/tmp/${videoTitle}.mp4`; 
 const writer = fs.createWriteStream(filePath);

 const videoStream = await axios({
 method: 'GET',
 url: videoDownloadUrl,
 responseType: 'stream'
 });

 videoStream.data.pipe(writer); 

 writer.on('finish', async () => {
 message.reply({
 body: `${videoTitle}`,
 attachment: fs.createReadStream(filePath)
 }, event.threadID, () => fs.unlinkSync(filePath), event.messageID); 
 });
 } else if (type === "a" || type === "-a") {
 const downloadBaseURL = "https://auandvi.onrender.com"; 
 const downloadURL = `${downloadBaseURL}/download?url=${encodeURIComponent(videoURL)}&type=mp3`;

 console.log("Download URL:", downloadURL); 

 const { data: downloadData } = await axios.get(downloadURL);
 console.log("Download Data:", downloadData); 

 if (!downloadData.download_url) {
 throw new Error("❌ | Error getting download URL from external service."); 
 }

 const fileName = downloadData.download_url.split("/").pop(); 
 const filePath = path.join(__dirname, "tmp", fileName);

 const fileDownloadURL = `${downloadBaseURL}/${downloadData.download_url}`; 

 await downloadFile(fileDownloadURL, filePath);
 console.log("File Downloaded to:", filePath); 

 message.reply({
 body: `${fileName.split('.').slice(0, -1).join('.')}`,
 attachment: fs.createReadStream(filePath),
 }, () => fs.unlinkSync(filePath)); 
 }
 } catch (error) {
 console.error("Error:", error.message);
 return message.reply(`❌ | An error occurred while processing your request.\n${error.message}`); 
 }
 },
 
};
