const ApprovalModel = require("../../database/models/mongodb/approve.js");

module.exports = {
 config: {
 name: "approve2",
 aliases: ['a'],
 version: "1.0",
 role: 2,
 author: "Nova",
 shortDescription: {
 en: "approve bot gc or request approval",
 },
 longDescription: {
 en: "approval and request approval for bot usage in a group chat.",
 },
 category: "owner",
 },

 onStart: async function ({ message, args, threadsData, api, event }) {
 if (args.length < 1) {
 message.reply("You must give an option: approve (add/delete/list/request) [thread ID]");
 return;
 }

 const action = args[0];
 const threadId = args[1];

 if (action === "add") {
 try {
 const threadData = await threadsData.get(threadId);
 const name = threadData.threadName;
 const existingApproval = await ApprovalModel.findOne({ threadID: threadId });

 if (!existingApproval) {
 await ApprovalModel.create({
 threadID: threadId,
 threadName: name,
 approvedBy: event.senderID,
 approvedAt: new Date()
 });
 message.reply(`Thread ${name} (${threadId}) approved successfully.`);
 api.sendMessage(`✅ | The group chat ${name} (${threadId}) has been approved and the bot is now active.`, threadId);
 } else {
 message.reply(`Thread ${threadId} is already approved.`);
 }
 } catch (err) {
 console.error(err);
 message.reply("An error occurred while approving the thread.");
 }
 } else if (action === "delete") {
 try {
 const threadData = await threadsData.get(threadId);
 const name = threadData.threadName;
 const deleteResult = await ApprovalModel.deleteOne({ threadID: threadId });

 if (deleteResult.deletedCount > 0) {
 message.reply(`Thread ${name} (${threadId}) unapproved.`);
 api.sendMessage("This group was unapproved. The bot will now leave the group.", threadId);
 setTimeout(async () => {
 await api.removeUserFromGroup(api.getCurrentUserID(), threadId);
 }, 5000); // 5 seconds
 } else {
 message.reply(`Thread ${threadId} was not approved before ❌`);
 }
 } catch (err) {
 console.error(err);
 message.reply("An error occurred while unapproving the thread.");
 }
 } else if (action === "list") {
 try {
 const approvedThreads = await ApprovalModel.find({});
 let threadList = "";
 approvedThreads.forEach((thread, index) => {
 threadList += `${index + 1}. ${thread.threadName} (${thread.threadID})\n`;
 });

 if (threadList === "") {
 message.reply("No threads approved.");
 } else {
 message.reply(`Approved threads:\n${threadList}`);
 }
 } catch (err) {
 console.error(err);
 message.reply("An error occurred while retrieving approved threads.");
 }
 } else if (action === "request") {
 message.reply("Requests are no longer supported in this version.");
 } else {
 message.reply("Invalid option. Please use 'add', 'delete', 'list', or 'request'.");
 }
 }
};