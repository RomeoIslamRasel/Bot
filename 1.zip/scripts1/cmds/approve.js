const { getStreamFromURL } = global.utils;
const ApprovalModel = require("../../database/models/mongodb/approve.js");

module.exports = {
    config: {
        name: "approve",
        aliases: ["app"],
        author: "ArYAN | Rômeo", // don't change my credit
        countDown: 10,
        role: 2,
        category: "owner",
        shortDescription: {
            en: "Approve Unapproved Groups Chats",
        },
    },

    onStart: async function ({ event, api, args }) {
        const { threadID, messageID, senderID } = event;
        const command = args[0] || "";
        const idToApprove = args[1] || threadID;
        const customMessage = args.slice(2).join(" ");
        const adminID = "5810140729080312";

        switch (command) {
            case "list":
                try {
                    const approvedThreads = await ApprovalModel.find({});
                    let msg = "✅ 𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 𝗚𝗿𝗼𝘂𝗽𝘀\n━━━━━━━━━━\n\nHere is the approved groups list\n";
                    for (let index = 0; index < approvedThreads.length; index++) {
                        const groupId = approvedThreads[index].threadID;
                        const threadInfo = await api.getThreadInfo(groupId);
                        const groupName = threadInfo ? (threadInfo.name || "Unnamed Group") : "Unnamed Group";
                        msg += `━━━━━━━[ ${index + 1} ]━━━━━━━\nℹ𝗡𝗮𝗺𝗲➤ ${groupName}\n🆔 𝗜𝗗➤ ${groupId}\n\n`;
                    }
                    api.sendMessage(msg, threadID, messageID);
                } catch (err) {
                    console.error(err);
                    api.sendMessage("An error occurred while listing approved groups.", threadID, messageID);
                }
                break;

            case "del":
                if (!isNumeric(idToApprove)) {
                    api.sendMessage("⚙ 𝗔𝗽𝗽𝗿𝗼𝘃𝗮𝗹 𝗦𝘆𝘀𝘁𝗲𝗺\n━━━━━━━━━━\n\nInvalid number or TID, please check your group number.", threadID, messageID);
                    return;
                }

                try {
                    const deleteResult = await ApprovalModel.deleteOne({ threadID: idToApprove });

                    if (deleteResult.deletedCount > 0) {
                        const threadInfoDel = await api.getThreadInfo(idToApprove);
                        const groupNameDel = threadInfoDel.name || "Unnamed Group";
                        api.sendMessage(`⚙ 𝗔𝗽𝗽𝗿𝗼𝘃𝗮𝗹 𝗦𝘆𝘀𝘁𝗲𝗺\n━━━━━━━━━━\n\nGroup has been removed from the approval list. \n🍁 | Group: ${groupNameDel}\n🆔 | TID: ${idToApprove}`, threadID, messageID);
                    } else {
                        api.sendMessage("⚙ 𝗔𝗽𝗽𝗿𝗼𝘃𝗮𝗹 𝗦𝘆𝘀𝘁𝗲𝗺\n━━━━━━━━━━\n\nThe group was not approved before!", threadID, messageID);
                    }
                } catch (err) {
                    console.error(err);
                    api.sendMessage("An error occurred while unapproving the group.", threadID, messageID);
                }
                break;

            case "batch":
                const idsToApprove = args.slice(1);
                let batchMessage = "⚙ 𝗔𝗽𝗽𝗿𝗼𝘃𝗮𝗹 𝗦𝘆𝘀𝘁𝗲𝗺\n━━━━━━━━━━\n\nApproved Groups:\n";
                try {
                    for (const id of idsToApprove) {
                        if (isNumeric(id)) {
                            const existingApproval = await ApprovalModel.findOne({ threadID: id });
                            if (!existingApproval) {
                                const threadInfoBatch = await api.getThreadInfo(id);
                                const groupNameBatch = threadInfoBatch.name || "Unnamed Group";
                                await ApprovalModel.create({
                                    threadID: id,
                                    threadName: groupNameBatch,
                                    approvedBy: senderID,
                                    approvedAt: new Date(),
                                });
                                batchMessage += `🍁 | Group: ${groupNameBatch}\n🆔 | TID: ${id}\n\n`;
                            }
                        }
                    }
                    api.sendMessage(batchMessage, threadID, messageID);
                } catch (err) {
                    console.error(err);
                    api.sendMessage("An error occurred while batch approving the groups.", threadID, messageID);
                }
                break;

            case "search":
                const searchTerm = args.slice(1).join(" ");
                try {
                    const approvedThreads = await ApprovalModel.find({});
                    let searchMsg = `⚙ 𝗔𝗽𝗽𝗿𝗼𝘃𝗮𝗹 𝗦𝘆𝘀𝘁𝗲𝗺\n━━━━━━━━━━\n\nSearch Results for "${searchTerm}":\n\n`;
                    for (let index = 0; index < approvedThreads.length; index++) {
                        const groupId = approvedThreads[index].threadID;
                        const threadInfoSearch = await api.getThreadInfo(groupId);
                        const groupNameSearch = threadInfoSearch ? (threadInfoSearch.name || "Unnamed Group") : "Unnamed Group";
                        if (groupNameSearch.includes(searchTerm) || groupId.includes(searchTerm)) {
                            searchMsg += `━━━━━━━[ ${index + 1} ]━━━━━━━\nℹ𝗡𝗮𝗺𝗲➤ ${groupNameSearch}\n🆔 𝗜𝗗➤ ${groupId}\n\n`;
                        }
                    }
                    api.sendMessage(searchMsg, threadID, messageID);
                } catch (err) {
                    console.error(err);
                    api.sendMessage("An error occurred while searching approved groups.", threadID, messageID);
                }
                break;

            default:
                if (!isNumeric(idToApprove)) {
                    api.sendMessage("⚙ 𝗔𝗽𝗽𝗿𝗼𝘃𝗮𝗹 𝗦𝘆𝘀𝘁𝗲𝗺\n━━━━━━━━━━\n\nInvalid Group UID, please check your group UID", threadID, messageID);
                } else {
                    try {
                        const existingApproval = await ApprovalModel.findOne({ threadID: idToApprove });
                        if (existingApproval) {
                            const threadInfo = await api.getThreadInfo(idToApprove);
                            const groupName = threadInfo.name || "Unnamed Group";
                            api.sendMessage(`⚙ 𝗔𝗽𝗽𝗿𝗼𝘃𝗮𝗹 𝗦𝘆𝘀𝘁𝗲𝗺\n━━━━━━━━━━\n\n🍁 Group: ${groupName} | TID: ${idToApprove} was already approved!`, threadID, messageID);
                        } else {
                            const threadInfo = await api.getThreadInfo(idToApprove);
                            const groupName = threadInfo.name || "Unnamed Group";
                            await ApprovalModel.create({
                                threadID: idToApprove,
                                threadName: groupName,
                                approvedBy: senderID,
                                approvedAt: new Date(),
                            });

                            const userInfo = await api.getUserInfo(senderID);
                            const userName = userInfo[senderID].name;
                            const userID = event.senderID;
                            const approvalTime = new Date().toLocaleTimeString();
                            const approvalDate = new Date().toLocaleDateString();
                            const approvalCount = await ApprovalModel.countDocuments({});

                            const approvalMessage = `🌟 **Approval Notification** 🌟\n━━━━━━━━━━━━━━━━━━\n **${groupName}** (TID: ${idToApprove}) has been successfully approved by **${userName}**.\n🔍 **Action ID:** ${userID}\n🕒 **Approval Time:** ${approvalTime} on ${approvalDate}\n\n📊 **Total Approved Groups:** ${approvalCount}`;

                            api.sendMessage(`⚙ 𝗔𝗽𝗽𝗿𝗼𝘃𝗮𝗹 𝗦𝘆𝘀𝘁𝗲𝗺\n━━━━━━━━━━\n\nGroup has been approved successfully:\n🍁 | Group: ${groupName}\n🆔 | TID: ${idToApprove}`, threadID);

                            const adminNotificationEnabled = true;
                            if (adminNotificationEnabled) {
                                api.sendMessage(approvalMessage, adminID);
                            }
                        }
                    } catch (err) {
                        console.error(err);
                        api.sendMessage("An error occurred while approving the group.", threadID, messageID);
                    }
                }
                break;
        }
    },
};

function isNumeric(value) {
    return /^-?\d+$/.test(value);
}
